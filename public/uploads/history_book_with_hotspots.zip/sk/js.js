$(function() {
  A5.LO_IFRAME_SIZE = [1005,695];

  a5.dp.config.allowLOSelfClosing = true;
  a5.dp.config.bookShowCurrentPagePlaceholder = true;
  a5.dp.config.bookDialogModal = false;
  a5.dp.config.bookNotesExportFormats = 'rtf, docx, pdf';
  a5.dp.config.bookTooltipDelay = 1000;
  a5.dp.config.bookTooltipDuration = 4000;
  a5.dp.config.bookZoomMarqueeClick = 60;
  a5.dp.config.bookZoomMax = 200;
  a5.dp.config.bookZoomMin = false;
  a5.dp.config.bookZoomPreserve = false;
  a5.dp.config.bookZoomSinglePage = 80;
  a5.dp.config.bookZoomStep = 20;
  a5.dp.config.protectBookPages = true;
  a5.dp.config.bookNotesAsTabPanel = true;
  a5.dp.config.bookNotesEditor = false;

  var userAgent = navigator.userAgent || navigator.vendor || window.opera;

  if (/iPad|iPhone|iPod/.test(userAgent) && !window.MSStream) {
      a5.dp.config.bookNotesExportFormats = 'rtf';
  }

});

+function() {
  var $iframe, $backdrop;

  var oldExtOpen = a5.views.interaction.PPEbookHotspotExternal.prototype.open;
  a5.views.interaction.PPEbookHotspotExternal.prototype.open = function() {
    oldExtOpen.apply(this, arguments);
    commonSetup(this.$iframe);
  };

  var oldPlatOpen = a5.views.interaction.PPEbookHotspotPlatform.prototype.open;
  a5.views.interaction.PPEbookHotspotPlatform.prototype.open = function() {
    oldPlatOpen.apply(this, arguments);
    commonSetup(this.$iframe);
  };

  function commonSetup(this$iframe) {
    if (this$iframe) {
      $iframe = this$iframe;
      $(window).on('resize', resizeIframe);
      resizeIframe();
    }
  }

  function resizeIframe() {
    var width, height,
        scale = Math.min($(window.top).width() / A5.LO_IFRAME_SIZE[0],
                         $(window.top).height() / A5.LO_IFRAME_SIZE[1]);
    if (scale < 1) {
      $('.neat-ios-fix:last').css('transform', 'scale(' + scale + ')');
      width = $(window.top).width() / scale;
      height = $(window.top).height() / scale;
    } else {
      $('.neat-ios-fix:last').css('transform', '');
      width = $(window.top).width();
      height = $(window.top).height();
    }
  }
}();

$(function() {
  $(document.body).toggleClass('isMobile', /Android|iPhone|iPad|iPod/i.test(navigator.userAgent));

  a5.callbacks.interaction.bind('showed', function() {
    $('.ebook').data('mvc-view').model.bind('page_change', function() {
      $('#audio-toolbar .stop').click();
    });
  });
});

$(function() {

	/**
	 * space between the outermost buttons and page turn buttons to be calculated so that it’s twice the distance calculated for the space between the buttons and vertical dividers.
	 * #7053
	 */
  function calculeSpace() {

  	var groups = $('.toolbar').children('.center').find('.group'),
    		width = $(window).width() - 161,
    		allGroupsWidth = 0,
    		separation = 0,
    		spaces = groups.length * 2 + 2;
    if (groups) {

    	groups.each(function(index, el) {
    		$(el).css({ 'padding-left' : 0, 'padding-right' : 0 })
    		allGroupsWidth += $(el).outerWidth();
    	});

    	separation =  parseInt( (width - allGroupsWidth) / spaces);

    	// add paddings
    	$('.toolbar').find('.center-wrap').css({ 'padding-left' : separation, 'padding-right' : separation });
    	groups.css({ 'padding-left' : separation, 'padding-right' : separation });

    }

  };

  //listeners:
  a5.hooks.interactionShowed.add( calculeSpace );
  window.addEventListener('resize', calculeSpace);

});

+function() {
  var $iframe, $backdrop;

  var oldExtOpen = a5.views.interaction.PPEbookHotspotExternal.prototype.open;
  a5.views.interaction.PPEbookHotspotExternal.prototype.open = function() {
    oldExtOpen.apply(this, arguments);
    commonSetup(this.$iframe);
  };

  var oldPlatOpen = a5.views.interaction.PPEbookHotspotPlatform.prototype.open;
  a5.views.interaction.PPEbookHotspotPlatform.prototype.open = function() {
    oldPlatOpen.apply(this, arguments);
    commonSetup(this.$iframe);
  };

  function commonSetup(this$iframe) {
    if (this$iframe) {
      $iframe = this$iframe;
      $(window).on('resize', resizeIframe);
      resizeIframe();
    }
  }

  function resizeIframe() {
    var width, height,
        scale = Math.min($(window.top).width() / A5.LO_IFRAME_SIZE[0],
                         $(window.top).height() / A5.LO_IFRAME_SIZE[1]);
    if (scale < 1) {
      $('.neat-ios-fix:last').css('transform', 'scale(' + scale + ')');
      width = $(window.top).width() / scale;
      height = $(window.top).height() / scale;
    } else {
      $('.neat-ios-fix:last').css('transform', '');
      width = $(window.top).width();
      height = $(window.top).height();
    }
  }
}();

$(function() {
  $(document.body).toggleClass('isMobile', /Android|iPhone|iPad|iPod/i.test(navigator.userAgent));

  a5.callbacks.interaction.bind('showed', function() {
    $('.ebook').data('mvc-view').model.bind('page_change', function() {
      $('#audio-toolbar .stop').click();
    });
  });
});

$(function() {

	/**
	 * space between the outermost buttons and page turn buttons to be calculated so that it’s twice the distance calculated for the space between the buttons and vertical dividers.
	 * #7053
	 */
  function calculeSpace() {

  	var groups = $('.toolbar').children('.center').find('.group'),
    		width = $(window).width() - 161,
    		allGroupsWidth = 0,
        preSeparation = 0,
    		separation = 0,
    		spaces = groups.length * 2 + 2,
        minSeparation = 10,
        maxSeparation = 40;

    if (groups) {

    	groups.each(function(index, el) {
    		$(el).css({ 'padding-left' : 0, 'padding-right' : 0 })
    		allGroupsWidth += $(el).outerWidth();
    	});

    	preSeparation =  parseInt( (width - allGroupsWidth) / spaces);
      separation = preSeparation - 3;
      if( separation > maxSeparation ) {
        separation = maxSeparation;
      } else if ( separation < minSeparation ){
        separation = minSeparation;
      }

    	// add paddings
    	$('.toolbar').find('.center-wrap').css({ 'padding-left' : separation, 'padding-right' : separation });
    	groups.css({ 'padding-left' : separation, 'padding-right' : separation });

    }

  };

  //listeners:
  a5.hooks.interactionShowed.add( calculeSpace );
  window.addEventListener('resize', calculeSpace);

  /**
   * MS Edge bug with centered text in an input txt with a place holder
   */
  function msInputBug (interaction) {

    $('.current-page').focusin(function () {
      $(this).attr('placeholder', '');
    });

    $('.current-page').focusout(function () {
      var txtval = $(this).attr('placeholder');
      if (txtval == "") {
          $(this).attr('placeholder', 'Go to page');
      }
    });

  }

  a5.hooks.interactionShowed.add( msInputBug );

});

