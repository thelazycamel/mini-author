// JavaScript Document
$(document).ready(function(e) {
	resolucion();
	$("#score").dialog({
		height:100,
		width:190,
		resizable:false,
		draggable:false,
		autoOpen:false,
		dialogClass:"position",
		title:"Score"
	});
	$(".dropAnsw").attr("padre",false);
	$("button").button();
	var drg;
    $(".ans").draggable({
		revert:"invalid",
		helper:"clone",
		drag:function(){
			drg = $(this).clone();
			drg.addClass("pos");
			}
		});
		
	$(".dropAnsw").droppable({
		accept:".ans",
		drop:function (){
			if($(this).attr("padre").toString()=="false"){
				$(this).append(drg);
				$(this).attr("padre",true);
				}
			},
		tolerance:"pointer"
	});
	$("#check").click(function(){
		tam = $("#cuest li").length;
		console.log(tam);
		var img, div, contador = 0;
		for(i = 0; i < tam; i++){
			hijos = $("#cuest li").get(i).childNodes;
			div = hijos.item(2);
			img = hijos.item(0);
			if(div.hasChildNodes()){
				if(div.getAttribute("res") == div.firstChild.getAttribute("res")){
					contador++;
					img.setAttribute("src","img/correct.png");					
				}
				else
					img.setAttribute("src","img/incorrect.png");
			}
			else
				img.setAttribute("src","img/incorrect.png");
		}
		
		
		$("#cuest li img").css("visibility","visible");
		
		$("#score p").css("text-align","center");
		if(contador==10){
			$("#score p").text(contador+"/10\n Awesome!");
			$("#score p").css("font-size","15px");
			$("#score p").css("margin","-4% 20%");
		}
		else{
			$("#score p").text(contador+"/10");
			$("#score p").css("margin","0% 12%");
		}
		$("#score").dialog("open");
		
	});
	
	$("#restart").click(function(){
			var hijos, tam = $("#cuest li div").length;
			for(i = 0; i < tam; i++){
				hijos = $("#cuest li div").get(i);
				if(hijos.hasChildNodes()){	
					hijos.removeChild(hijos.firstChild);
					hijos.setAttribute("padre",false);
				}
			}
			$("#score").dialog("close");
			$("#cuest li img").css("visibility","hidden");
		});
});


function resolucion(){
	var ancho = screen.width;
	var alto = screen.height;
	console.log(ancho+"  "+alto);
	if(ancho == 768 && alto == 1024)
		$("#style").attr("href","css/activity2/index7.css");
	else if(ancho == 1280 && alto == 752)
		$("#style").attr("href","css/activity2/index10_1.css");
	else if(ancho >= 1024 && alto >= 768)
		$("#style").attr("href","css/activity2/index.css");
	else if(ancho == 1024 && alto == 600)
		$("#style").attr("href","css/activity2/index1024_600.css");
	else
		$("#style").attr("href","css/activity2/index800_600.css");
}