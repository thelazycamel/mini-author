// JavaScript Document
$(document).ready(function(e) {
	resolucion();
	$("button").button();
	var solutions = ["theirare","youris","ouraren't","myare","youmy","heris","hisare","they're","weour","hisis"];
	$("#score").dialog({
		height:100,
		width:190,
		resizable:false,
		draggable:false,
		autoOpen:false,
		dialogClass:"position",
		title:"Score"
	});
	$("#check").click(function(){
		var contador = 0;
		var aux;
		var img = $(".answer");
		var hijo = new Array();
		hijo[0] = $(".opc option:selected").get(0).getAttribute("value")+$(".opc option:selected").get(1).getAttribute("value");
		hijo[1] = $(".opc option:selected").get(2).getAttribute("value")+$(".opc option:selected").get(3).getAttribute("value");
		hijo[2] = $(".opc option:selected").get(4).getAttribute("value")+$(".opc option:selected").get(5).getAttribute("value");
		hijo[3] = $(".opc option:selected").get(6).getAttribute("value")+$(".opc option:selected").get(7).getAttribute("value");
		hijo[4] = $(".opc option:selected").get(8).getAttribute("value")+$(".opc option:selected").get(9).getAttribute("value");
		hijo[5] = $(".opc option:selected").get(10).getAttribute("value")+$(".opc option:selected").get(11).getAttribute("value");
		hijo[6] = $(".opc option:selected").get(12).getAttribute("value")+$(".opc option:selected").get(13).getAttribute("value");
		hijo[7] = $(".opc option:selected").get(14).getAttribute("value");
		hijo[8] = $(".opc option:selected").get(15).getAttribute("value")+$(".opc option:selected").get(16).getAttribute("value");
		hijo[9] = $(".opc option:selected").get(17).getAttribute("value")+$(".opc option:selected").get(18).getAttribute("value");
		
		for(i=0; i < hijo.length; i++){
			if(hijo[i].toString() == solutions[i].toString()){
				contador++;
				img.get(i).setAttribute("src","img/correct.png");
			}
			img.css("visibility","visible");
		}
		if(contador==10){
			$("#score p").text(contador+"/10\n Awesome!");
			$("#score p").css("font-size","15px");
			$("#score p").css("margin","-4% 20%");
		}
		else{
			$("#score p").text(contador+"/10");
			$("#score p").css("margin","0% 12%");
		}
		
		$("#score").dialog("open");
		});
		
		$("#restart").click(function(){
			$("select").val("0");
			$("#score").dialog("close");
			$(".answer").css("visibility","hidden");
		});
});


function resolucion(){
	var ancho = screen.width;
	var alto = screen.height;
	console.log(ancho+"  "+alto);
	if(ancho == 768 && alto == 1024)
		$("#style").attr("href","css/activity3/index7.css");
	else if(ancho == 1280 && alto == 752)
		$("#style").attr("href","css/activity3/index10_1.css");
	else if(ancho >= 1024 && alto >= 768)
		$("#style").attr("href","css/activity3/index.css");
	else if(ancho == 1024 && alto == 600)
		$("#style").attr("href","css/activity3/index1024_600.css");
	else
		$("#style").attr("href","css/activity3/index.css");
}

