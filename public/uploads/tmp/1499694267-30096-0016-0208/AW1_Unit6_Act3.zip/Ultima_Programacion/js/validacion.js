// JavaScript Document

$(document).ready(function(e) {
	//alert("Ancho: "+screen.width +" px  Alto: "+screen.height+" px");
	resolucion();
$("button").button();
$("#score").dialog({
	height:100,
	width:190,
	resizable:false,
	draggable:false,
	autoOpen:false,
	dialogClass:"position",
	title:"Score"
});

$("#check").click(function(){
	//console.log("Click");
	var sol = new Array();
	var img = $(".answer");
	sol[0] = "What is his name ";
	sol[1] = "How old is he ";
	sol[2] = "What is his job ";
	sol[3] = "Where is he from ";
	sol[4] = "What is his telephone number ";
	sol[5] = "What is his girlfriend's job ";
	sol[6] = "Who is his favorite superhero ";
	console.log("Se inicializaron las respuestas");
	var question = new Array();
	question[0] = $(".question1");
	question[1] = $(".question2");
	question[2] = $(".question3");
	question[3] = $(".question4");
	question[4] = $(".question5");
	question[5] = $(".question6");
	question[6] = $(".question7");
	console.log("Se cargaron las respuestas del usuario");
	
	var answers = new Array();
	answers[0] = cadena(question[0]);
	answers[1] = cadena(question[1]);
	answers[2] = cadena(question[2]);
	answers[3] = cadena(question[3]);
	answers[4] = cadena(question[4]);
	answers[5] = cadena(question[5]);
	answers[6] = cadena(question[6]);
	var k=0;
	for(i = 0; i < 7; i++){
		if(validar(answers[i], sol[i])){
			k++;
			$(".answer").get(i).setAttribute("src","img/correct.png");
		}
		$(".answer").css("visibility","visible");
			
	}
	console.log(k);
	$("#score p").css("margin","0 37%");
	$("#score p").text(k+"/7");
	$("#score").dialog("open");
	
});

$("#restart").click(function(){
	$("#score").dialog("close");
	$(".answer").css("visibility","hidden");
	$("input").val("");
	});
	
});

function cadena(question){
	var res="";
	var minus="";
	for (i = 0; i<question.size(); i++){
	//while(question.get(i).value != "")
		res+=question.get(i).value+" ";
	//	console.log(res);
	}
	minus = res.toLowerCase();
	console.log(minus);
	return minus;
}

function validar(cadena, solucion){
	if(cadena==solucion)
		return true;
	else
		return false;
}

function resolucion(){
	var ancho = screen.width;
	var alto = screen.height;
	console.log(ancho+"  "+alto);
	if(ancho == 768 && alto == 1024)
		$("#style").attr("href","css/index7.css");
	else if(ancho == 1280 && alto == 752)
		$("#style").attr("href","css/index10_1.css");
	else if(ancho >= 1024 && alto >= 768)
		$("#style").attr("href","css/index.css");
	else if(ancho == 1024 && alto == 600)
		$("#style").attr("href","css/index1024_600.css");
	else
		$("#style").attr("href","css/index800_600.css");
}