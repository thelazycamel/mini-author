
var score=0;

$(document).on('ready', inicio);

function inicio()
{

	//listener botones

	$('#check').on('click', check);
	$('#trya').on('click', trya);
}

function check(){
    	startSession();		// START SCORM SESSION
//PRIMERA COLUMNA
	var aux=1;
	$('#iz').children('li').each(function(j){
			$(this).children('select').each(function(i){
				if($(this).val()==i){
				aux=aux*1;
				//$('<span class="feed" data-icon="p" ></span>').appendTo($('#iz').children('li'));
				}else{
				aux=aux*0;
				$('<span class="feed" data-icon="x" ></span>').appendTo($(this).parent());
				return false;
				}
				
	});
	
	if(aux==1){
			$('#second').children('li').each(function(index,element){
					if($(this).attr('data-order')==(j+1)){
							if($(this).children('p').children('select').val()==1){
							score++;
            setInfoQuest("AW01", 6, 3, index, "Unscramble the questions and then match them with the answers.", "2",  "1", "1");
							//CORRECTA
							$('<span class="feed" data-icon="p" ></span>').appendTo($(this));
            setInfoQuest("AW01", 6, 3, index, "Unscramble the questions and then match them with the answers.", "2",  "1", "0");
							}else{	
							//$('<span class="feed" data-icon="x" ></span>').appendTo($(this));
                            
							}
						}
			});
		}
	aux=1;
	
           
	});



		window.scrollTo(0,0);
		$('#check').off();
		$('<div>Score <img src="img/x1.png"> </div> <div>'+score+'/10</div>').appendTo('#score');$('#score div img').on('click', function(){$(this).parent().parent().hide();});
		$('#score').show();

	setInfoSco(score,10);	// ADDING SCO PARAMETERS

	finishSession();		// FINISH SCORM SESSION	
}

function trya()
{
	location.reload(true);
}