
/*	VARIABLES GLOBALES PARA USO DE SCORM 	*/

var lmsonline = false;
var debug = true;
var iniciado = false;

window.onbeforeunload = function(e) {
    
    if(!iniciado)
    	startSession();
    finishSession();

};

function startSession(){

iniciado = true;

try {

	pipwerks.SCORM.handleCompletionStatus = false;
	lmsonline = pipwerks.SCORM.init();

	if (lmsonline){
		console.log("LMS connected");
	}else{
		console.log("Starting session failed");
	
	}

}catch(err) {
	console.log("Error startSession: " + err.message);
}

}

function setInfoSco(scoreRaw, scoreMax){

	if (debug)
		console.log("Info SCO: " + "\nScoreMax: " + scoreMax + "\nScoreRaw: " + scoreRaw);

try {

	if (lmsonline){
		var completion_status = "cmi.completion_status";
		var total_time = "cmi.total_time";
		var score_raw = "cmi.score.raw";
		var score_min = "cmi.score.min";
		var score_max = "cmi.score.max";
		var score_scaled = "cmi.score.scaled";

		if (scoreRaw == scoreMax){
			pipwerks.SCORM.set(completion_status, "complete");
		}else{
			if (scoreRaw == 0){
				pipwerks.SCORM.set(completion_status, "not attempted");
			}else{
				pipwerks.SCORM.set(completion_status, "incomplete");
			}
		}

		//pipwerks.SCORM.get(total_time, totalTime);	// DATA MODEL CAN ONLY BE READ
		pipwerks.SCORM.set(score_raw, scoreRaw);
		pipwerks.SCORM.set(score_min, scoreMax);
		pipwerks.SCORM.set(score_max, scoreMax);
		pipwerks.SCORM.set(score_scaled, (scoreRaw/scoreMax));

		pipwerks.SCORM.save();
	}else
		console.log("Failed setInfoSco - LMS no connected")

}catch(err) {
	console.log("Error en setInfoSco: " + err.message);
}

}

function setInfoQuest(serie, noLevel, noActivity, noQuestion, instruction, type, correct_response, student_response){


	if (debug)
		console.log("Datos setInfoQuest: " + "\nSerie:" + serie + "\nnoLevel:" + noLevel + "\nnoActivity:" + noActivity + "\nnoQuestion:" + noQuestion + "\nInstruction:" + instruction + "\nType:" + type + "\nCorrect Response:" + correct_response + "\nStudent Response:" + student_response);


	if (lmsonline)
try{

	switch(type){
		case "1": type = "true-false";
		break;
		case "2": type = "choice";
		break;
		case "3": type = "fill-in";
		break;
		case "4": type = "long-fill-in";
		break;
		case "5": type = "matching";
		break;
		case "6": type = "performance";
		break;
		case "7": type = "sequencing";
		break;
		case "8": type = "likert";
		break;
		case "9": type = "numeric";
		break;
		case "10": type = "other";
		break;
	}

	var interaccion = pipwerks.SCORM.data.get("cmi.interactions._count");
	var interactions_n_id = "cmi.interactions." + interaccion + ".id";
	var interactions_n_descriptions = "cmi.interactions." + interaccion + ".description";
	var interactions_n_type = "cmi.interactions." + interaccion + ".type";
	var interactions_n_timestamp = "cmi.interactions." + interaccion + ".timestamp";
	var interactions_n_correct_responses_m_pattern = "cmi.interactions." + interaccion + ".correct_responses.0.pattern";
	var interactions_n_student_response = "cmi.interactions." + interaccion + ".learner_response";
	var objetives_n_id = "cmi.objectives." + interaccion + ".id";
	var objetives_n_completion_status = "cmi.objectives." + interaccion + ".completion_status";
	var objetives_n_score_raw = "cmi.objectives." + interaccion + ".score.raw";
	var objetives_n_score_max = "cmi.objectives." + interaccion + ".score.max";

	pipwerks.SCORM.set(interactions_n_id, (serie + "-" + noLevel.toString() + "-" + noActivity.toString() + "-" + noQuestion.toString()));
	pipwerks.SCORM.set(interactions_n_descriptions, instruction);
	pipwerks.SCORM.set(interactions_n_type, type);
	pipwerks.SCORM.set(interactions_n_timestamp, (new Date().getTime()));
	pipwerks.SCORM.set(interactions_n_correct_responses_m_pattern, correct_response);
	pipwerks.SCORM.set(interactions_n_student_response, student_response);
	pipwerks.SCORM.set(objetives_n_id, (serie + "-" + noLevel.toString() + "-" + noActivity.toString() + "-" + noQuestion.toString()));

	if (correct_response == student_response){
		pipwerks.SCORM.set(objetives_n_completion_status, "complete");
		pipwerks.SCORM.set(objetives_n_score_raw, 1);
	}
	else
		if (student_response == ""){
			pipwerks.SCORM.set(objetives_n_completion_status, "not attempted");
			pipwerks.SCORM.set(objetives_n_score_raw, 0);
		}
		else{
			pipwerks.SCORM.set(objetives_n_completion_status, "incomplete");
			pipwerks.SCORM.set(objetives_n_score_raw, 0);
		}
		
	pipwerks.SCORM.set(objetives_n_score_max, 1);

}catch(err) {	
	console.log("Error en setInfoQuest: " + err.message);
}else
 	console.log("Failed setInfoQuest " + noActivity + " - "  +noQuestion + " - LMS no connected")



}


function finishSession(){

	pipwerks.SCORM.save();
	var quit = pipwerks.SCORM.quit();
	if (quit)
		console.log("Finish session correctly");
	else
		console.log("Failed quitting session");	
}


